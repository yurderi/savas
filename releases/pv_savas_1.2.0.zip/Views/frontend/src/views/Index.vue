<template>
    <div class="view is--index">
        <v-header></v-header>
        <v-content>
            Statistics (how much downloads, releases, requests) <br />
            Feedback submissions (which application, when, etc ...) <br />

        </v-content>
    </div>
</template>