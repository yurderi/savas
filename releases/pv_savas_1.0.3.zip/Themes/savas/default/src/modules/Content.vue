<template>
    <div class="content-container">
        <div class="content">
            <slot></slot>
        </div>
    </div>
</template>